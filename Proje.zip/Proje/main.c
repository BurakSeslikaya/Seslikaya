#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int wuser(int*);

void main() {
	FILE *sifre1, *names, *surnames, *sales, *hmuserp, *passwords, *product, *wproductsp;
	int  whone, counter = 0, abcd = 0, for1, digits = 1, *passofusers, wproduct3, abtf, wproduct4, mychoose, userchoose, for2, hmuser, for3, mychoose2;
	int  for4, atc, abccd, btc, ctc, whccas, case2, infiniteproduct = 1, wproduct1, wproduct2, priceofproduct, wproduct, tryagain1 = 0, tryagain2 = 0, btf, etc, infiniteopen, dtc, newpass, check1;
	int sca1, namesa, number1, agdc, counter3, seekcounter2, whileender, whilebreaker = 0, for8, hmsell = 0, abd, conorcan, for7, for6, control = 1;
	long long1, barlong, code2;
	char *name, *surname, my[15], nameof[10], passwordof2[10], surnameof[15], choose1, n2, passwordof[10], *barcoderead, productp, *naofpro, proname, ender, *printing, n1 = ' ', changensun;
	while(infiniteopen != 1){
	    whone = wuser(&whccas);
		if(whone == 616161){   // e�er kurtarma kodu girildiyse ma�aza y�netici �ifresi de�i�tirilecek
			printf("password of manager: ");
			gets(my);
			sifre1 = fopen("magazayonetici.txt", "w");
			fprintf(sifre1,"%s", my);   //ma�aza y�neticisinin �ifresi magazayonetici.txt ye kaydedildi
			fclose(sifre1);
		}
		else{
			
			switch(whone){
				case 0:
					printf("\nWrong password try again");
					break;
				case 1:   // ma�aza y�neticisi
					printf("Choose the number\n1- Change informations of users\n2- Adding new products to sell(or change the price of it)\n3- Total profit(or money that have been lost)\n4- Change how much products costs to buyers");
					printf("\n5- tax\n6- Which products sold by which cashier\n7- How much money must be in cash register\n8- Customers and sales for them\n");
					scanf("%d", &mychoose);
					system("cls");
					while(tryagain1 = 1){
					switch(mychoose){
						case 1:  //Change of info
							printf("Create user or change user information\n");
							printf("1- for create\n2- for change\n");
							scanf("%d", &userchoose);
							system("cls");
							switch(userchoose){
								case 1:
									printf("How much user you want to create:\n");
									scanf("%d", &hmuser);
									system("cls");
									hmuserp = fopen("hmuser.txt", "w");
									fprintf(hmuserp,"%d", hmuser);
									fclose(hmuserp);
									names = fopen("isimler.txt", "w");
									passwords = fopen("sifreler.txt", "w");
									for(for4=0; for4<hmuser; for4++){
										fprintf(names,"                         ");  //en fazla 25 karakter girilebilir.
										fprintf(passwords,"          ");  // 10
									}
									for(for1=0; for1<hmuser; for1++){
										agdc = for1 + 1;
										printf("Enter name of user %d:\n", agdc);
										scanf("%s", nameof);
										system("cls");
										printf("Enter surname of user %d:\n", agdc);
										scanf("%s", surnameof);
										system("cls");
										for(for2=0; for2<1; for2++){
										    printf("Enter password of user %d\n", agdc);  //isimler ve soyisimler al�nd� �imdi �ifre al�n�yor
											scanf("%s", passwordof);
											system("cls");
											printf("Enter the password again\n");
											scanf("%s", passwordof2);
											system("cls");
											if(strcmp(passwordof,passwordof2)==0)  //e�er girdi�i iki �ifre yanl��sa �ifreleri tekrar istiyor
												for2 = 1;
											else{
												for2--;
												printf("two passwords are not identical please enter the password again\n");
											}
										}
										btf = for1 * 10;
										atc = for1 * 25;
										fseek(names,atc,SEEK_SET);
										fprintf(names,"%s %s,", nameof, surnameof);
										fseek(passwords,btf,SEEK_SET);
										fprintf(passwords,"%s,", passwordof);   // ayn� anda iki tane a� hem say� hem harf harf � yi g�r�nce d�ng� bitsin ////////// 9 haneli �ifre
									}
									fclose(names);
									fclose(passwords);
									break;
								case 2:
									printf("Which mans or womans information you want to change\n");
									names = fopen("isimler.txt", "r");  // ilk � ikinci � gibi gidecek ve isim soyisimleri toplayacak
									printing = (char*)malloc(20*sizeof(char));
									hmuserp = fopen("hmuser.txt", "r");
									fscanf(hmuserp,"%d", &hmuser);
									fclose(hmuserp);
									for(for3=0; for3<hmuser; for3++){
										btc = for3 * 25;
										fseek(names,btc,SEEK_SET);
										n2 = getc(names);
										while(n2 != ','){
											fseek(names,-1,SEEK_CUR);
											n1 = getc(names);
											printing[counter] = n1;
											counter++;
											n2 = getc(names);
										}
										counter = 0;
									    abtf = for3 + 1;
									    printf("%d- %s\n", abtf, printing);
										free(printing);
									}
									fclose(names);
									scanf(" %s ", choose1);
									system("cls");
									if((choose1<=0)||(choose1>hmuser)){
										printf("there is no such a user\nEnter number again.");
										scanf("%d", &choose1);
									}
									ctc = choose1--;
									ctc = ctc * 25;
									etc = choose1--;
									etc = etc * 10;
									printf("Do you want to change password or user name and surname\n1- Password\n2- Name and surname");
									scanf("%d", &dtc);
									while(check1 != 1){
										switch(dtc){
											case 1:
												passwords = fopen("sifreler.txt","w+");
												fseek(passwords,etc,SEEK_SET);
												fprintf(passwords,"          ");
												printf("\nWrite the new password");
												scanf("%d", &newpass);
												fclose(passwords);
												passwords = fopen("sifreler.txt", "w+");
												fprintf(passwords,"%d,", newpass);
												fclose(passwords);
												check1 = 1;
												break;
											case 2:
												names = fopen("isimler.txt", "w+");
												fseek(names,ctc,SEEK_SET);
												fprintf(names,"                         ");
												fclose(names);
												printf("write the new name and surname\n");
												scanf("%s", changensun);
												names = fopen("isimler.txt", "w+");
												fseek(names,ctc,SEEK_SET);
												fprintf(names,"%s,", changensun);
												fclose(names);
												check1 = 1;
												break;
											default:
												printf("You entered wrong number enter the number again");
												scanf("%d", &dtc);
												check1 = 0;
												break;
									}
									}
									break;
								}
							tryagain1 = 0;
							break;
						case 2:
							// barkodlar 13 haneli oluyorlar
							printf("Do you want to add new product(1)or change price of products(2)\n");
							scanf("%d", &case2);
							while(tryagain2 = 1){
								switch(case2){
									case 1:
										while(infiniteproduct = 1){
											printf("\nPlease enter the barcode of product(13 digit):");
											scanf("%l", &long1);
											while(digits != 0){
												if(long1 > 9999999999999){
													printf("\nYou cant write more than 13 digits\nWrite the barcode again:\n");
													scanf("%l", long1);
												}
												else
													digits = 0;
											}
											product = fopen("products.txt", "w+");
											wproductsp = fopen("wproducts.txt","r");
											fscanf(wproductsp,"%d", &wproduct);
											fclose(wproductsp);
											wproductsp = fopen("wproducts","w");
											wproduct++;
											fprintf(wproductsp,"%d", wproduct);  //toplam ka� product var
											fclose(wproductsp);
											wproduct--;
											wproduct1 = wproduct * 41;
											fseek(product,wproduct1,SEEK_SET);
											fprintf(product,"                                         ");  // 13 for barcode 21 for name 7 for price
											fclose(product);
											product = fopen("products.txt","w+");
											printf("\nPlease enter name of product(at most type 20 character)");
											scanf("%s", proname);
											printf("\nPlease enter price of it");
											scanf("%d", &priceofproduct);
											int pricecheck = 0;
											while(pricecheck != 1){
												if(priceofproduct > 999999){
													printf("\nPlease enter acceptable number:\n");
													scanf("%d", &priceofproduct);
												}
												else
												pricecheck = 1;
											}
											wproduct2 = wproduct * 41;
											fseek(product,wproduct2,SEEK_SET);
											fprintf(product,"%l", long1);
											wproduct3 = wproduct2 + 13;
											fseek(product,wproduct3,SEEK_SET);
											fprintf(product,"%s,", proname);
											wproduct4 = wproduct3 + 21;
											fseek(product,wproduct4,SEEK_SET);
											fprintf(product,"%l,", long1);
											fclose(product);
										}
										tryagain2 = 0;
										break;
									case 2:
										printf("which product information you want to change?");
										product = fopen("products.txt","r");
										wproductsp = fopen("wproducts.txt","r");
										int wprocount, control1, whcone, checkchoice, counter2 = 0, choiceofpro, seekcounter, for5;
										char  *productp,whileender = ' ';
										fscanf(wproductsp,"%d", &wprocount);
										fclose(wproductsp);
										for(for5=0; for5<wprocount; for5++){
										productp = (char*)malloc(21*sizeof(char));
											seekcounter = for5 * 41;
											seekcounter = seekcounter + 13;
											fseek(product,seekcounter,SEEK_SET);
											while(whileender != ','){
												productp[counter2] = whileender; 
												counter2++;
												whileender = fgetc(product);
											}
											whileender = ' ';
											printf("%d- %s", for5++, productp);
											free(productp);
										}
										scanf("%d", &choiceofpro);
										while(checkchoice != 1){
											if((choiceofpro < 1)||(choiceofpro > wprocount)){
												printf("\nYou cant type that. Type again.");
												scanf("%d", choiceofpro);
												checkchoice = 1;
											}
											else
											checkchoice = 0;
										}
										printf("\nWhat do you want to change\n1- barcode\n2- name\n3- price");
										scanf("%d", &whcone);
										while(control1 = 1){
											if((whcone < 1)||(whcone > 3)){
												printf("\nThere is no such a thing. Type again\n");
												scanf("%d", &whcone);
												control1 = 1;
											}
											else
											control1 = 0;
										}
										long long2;
										fclose(product);
										product = fopen("products.txt", "w+");
										choiceofpro--;
										int choiceofpro1, choiceofpro2, choiceofpro3;
										choiceofpro1 = choiceofpro * 41;
										choiceofpro2 = choiceofpro1 + 13;
										choiceofpro3 = choiceofpro2 + 21;
										char string1;
										int price1;
										switch(whcone){
											case 1:
												printf("\nEnter the new barcod");
												scanf("%l", &long2);
												fseek(product,choiceofpro,SEEK_SET);
												fprintf(product,"             ");
												fseek(product,choiceofpro,SEEK_SET);
												fprintf(product,"%l", long2);
												fclose(product);
												break;
											case 2:
												printf("\nEnter the new name:\n");
												scanf("%s", string1);
												fseek(product,choiceofpro2,SEEK_SET);
												fprintf(product,"                     ");
												fseek(product,choiceofpro2,SEEK_SET);
												fprintf(product,"%s,", string1);
												fclose(product);
												break;
											case 3:
												printf("\nPlease enter the new price");
												scanf("%d", &price1);
												fseek(product,choiceofpro3,SEEK_SET);
												fprintf(product,"       ");
												fseek(product,choiceofpro3,SEEK_SET);
												fprintf(product,"%d,", price1);
												fclose(product);
												break;
										}
										tryagain2 = 0;
										break;
									default:
										printf("\nWrong number. Write the number again");
										scanf("%d", &case2);
										tryagain2 = 1;
										break;
								}
							}
							tryagain1 = 0;
							break;
						case 3:
							
							break;
						case 4:
							
							break;
						case 5:
							
							break;
						case 6:
							
							break;
						case 7:
							
							break;
						case 8:
							
							break;
						default:
							printf("\nwrong number. Try again\n");
							scanf("%d", &mychoose);
							tryagain1 = 1;
							break;
				}
			case 2:  //ELEMAN
				sales =  fopen("satislar.txt", "w+");
				printing = (char*)malloc(25*sizeof(int));
				names = fopen("isimler.txt", "r");
				counter = 0;
				btc = whccas * 25;
				fseek(names,btc,SEEK_SET);
				while(n1 != ','){
					printing[counter] = n1;
	 				counter++;				
					n1 = getc(names);
				}
				n1 = ' ';
				printf("\nCashier %s\n", printing);
				fclose(names);
				printf("1- Sale\n2- Exit");
				scanf("%d", &sca1);
				while(control = 1){
					if((sca1 < 1)||(sca1 > 2)){
						printf("\nThere is no such a thing. Try again.\n");
						scanf("%d", &sca1);
						control = 1;
					}
					else
					control = 0;
					free(printing);
				}
				switch(sca1){
					case 1:
						printf("Enter the barcode");
						scanf("%l", &barlong);
						product = fopen("products.txt", "r");
						wproductsp = fopen("wproducts","r");
						fread(&number1,sizeof(int),1,wproductsp);
						fclose(wproductsp);
						barcoderead = (char*)malloc(13*sizeof(char));
						for(for6=0; for6<number1; for6++){
							abd = for6 * 41;
							fseek(product,abd,SEEK_SET);
							for(for7=0; for7<13; for7++){
								barcoderead[for7] = getc(product);
							}
							sscanf(barcoderead,"%l", &code2);   // B�YLE OLUYORMU?
							if(code2==barlong){
								naofpro = (char*)malloc(21*sizeof(char));
								seekcounter2 = abd + 13;
								fseek(product,seekcounter2,SEEK_SET);
								while(ender != ','){  //kasiyerin ge�irdi�i malzemenin ismi
									naofpro[counter3] = ender; 
									counter3++;
									ender = fgetc(product);
								}
								whileender = ' ';
								printf("%s", productp);
								while(whilebreaker != 1){
									printf("\n1- continue\n2- cancel\n3- End");
									free(barcoderead);
									scanf("%d", &conorcan);
									switch(conorcan){
										case 1:  //ge�ici bir �ekilde fiyat� tutulacak ekrana verilecek ve bir di�er barcod istenecek
											hmsell++;
											
											whilebreaker = 1;
											break;
										case 2:  //ge�irilinen malzeme kaydedilmeycek         �STEN�RSE K�M KA� KERE B��EYLER� �PTAL ETM�� G�REB�LECEK
											
											whilebreaker = 1;
											break;
										case 3:  //sonucu g�sterecek
											break;
										default:
											printf("\nwrong key. Try again.");
											whilebreaker = 0;
											break;
									}
								}
								free(naofpro);
								break;
							}
							}
						fclose(product);
						free(barcoderead);
						break;
					case 2:
						
						break;
				}
				break;
		    }
			} 
		}
	}
}
int wuser(int *whccas){  //hangi kullan�c� oldu�unu do�ruluyor
	FILE *fp1, *fp3, *fp4;
	int abc, pass, hmus, for1fun;
	char passgiven[20], abbc[20];
	gets(abbc);
	fp1 = fopen("magazayonetici.txt","r");
	fgets(passgiven,15,fp1);
	fclose(fp1);
	fp4 = fopen("hmuser.txt", "r");
	fread(&hmus,sizeof(int),1,fp4);
	fclose(fp4);
	fp3 = fopen("sifreler.txt", "r");
	system("cls");
	if(strcmp("616161", abbc)==0)
		return 616161;
	if(strcmp(passgiven,abbc)==0)
	    return 1;
	else{
		int abc, adc, checkifr = 0, counter = 0;
		char char1, *char2;
		for(for1fun=0; for1fun<hmus; for1fun++){
			counter = 0;
			char2 = (char*)malloc(10*sizeof(char));
			abc = for1fun * 10;
			fseek(fp3,abc,SEEK_SET);
			char1 = getc(fp3);
			fseek(fp3,abc,SEEK_SET);
			while(char1 != ','){
				char2[counter] = getc(fp3);
				counter++;
				char1 = fgetc(fp3);
				fseek(fp3,counter,SEEK_SET);
			}
			adc = strcmp(char2, abbc);
			if(adc = 0){
				whccas = &for1fun;                   // 1. kullan�c� ise 0
				fclose(fp3);
				checkifr = 1;
				return 2;
				break;
			}
		}
		if(checkifr != 1){
			return 0;
		}
	}
}
