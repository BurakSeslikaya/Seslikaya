#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int wuser(int*);

struct allot{
	char passs[10];
};
struct info{
	char name1[12];
	char sname[15];
};
struct prod{
	char barcod[14];
	char pname[25];
	int price;
};
struct sell{
	int which;
	char barpro[14];
};
void main() {
	FILE *sifre1, *names, *surnames, *sales, *hmuserp, *passwords, *product, *wproductsp, *tempsell, *hmsellf, *sells, *wproductp1;
	int  whone, counter = 0, abcd = 0, for1, digits = 1, num2, agt, mbw, wprocount, whcone, *passofusers, wproduct3, for11, control1, httf, wusers, abtf, wproduct4, mychoose, userchoose, for2, hmuser, for3, mychoose2, conorcan;
	int  for4, atc, abccd, btc, ctc,whccas, case2, infiniteproduct = 1, checkchoice, wproduct1, wproduct2, priceofproduct, ctr = 0, prosp, wproduct, tryagain1 = 0, tryagain2 = 0, btf, etc, infiniteopen, dtc, check1 = 0;
	int sca1, namesa, number1 = 0, agdc, counter3, seekcounter2, choiceofpro, ohmsell, abrr, tamount = 0, whileender, temp, for5, agr, arr, hmusert, whilebreaker = 0, for8, for12, hmsell = 0, atf, choose1, abd, for7, for6, control = 1;
	long long1, barlong, code2;
	char *name, *surname, str2[14], my[15], passwordof2[10], *printing, n2, passwordof[10], *barcoderead, barcs[14], productp[15], *naofpro, proname, ender, n1 = ' ', newpass[10], changensun;
	int testint = 0;
	while(infiniteopen != 1){
	    whone = wuser(&whccas);
	    system("cls");
		if(whone == 616161){   // e�er kurtarma kodu girildiyse ma�aza y�netici �ifresi de�i�tirilecek
			printf("password of manager: ");
			gets(my);
			sifre1 = fopen("magazayonetici.txt", "w");
			fprintf(sifre1,"%s", my);   //ma�aza y�neticisinin �ifresi magazayonetici.txt ye kaydedildi
			fclose(sifre1);
		}
		else{
			
			switch(whone){
				case 0:
					printf("\nWrong password try again\n");
					break;
				case 1:   // ma�aza y�neticisi
					printf("Choose the number\n1- Change informations of users\n2- Adding new products to sell(or change the price of it)\n3- Total profit(or money that have been lost)\n4- Change how much products costs to buyers");
					printf("\n5- tax\n6- Which products sold by which cashier\n7- How much money must be in cash register\n8- Customers and sales for them\n");
					scanf("%d", &mychoose);
					system("cls");
					switch(mychoose){
						case 1:  //Change of info
							printf("Create user or change user information\n");
							printf("1- for create\n2- for change\n");
							scanf("%d", &userchoose);
							system("cls");
							switch(userchoose){
								case 1:
									printf("How much user you want to create:\n");
									scanf("%d", &hmuser);
									system("cls");
									hmuserp = fopen("hmuser.txt","r");
									fscanf(hmuserp,"%d", &httf);
									fclose(hmuserp);
									hmusert = hmuser + httf;
									hmuserp = fopen("hmuser.txt", "w");
									fprintf(hmuserp,"%d", hmuser);
									fclose(hmuserp);
									names = fopen("isimler.txt", "r");
									passwords = fopen("sifreler.txt", "r");
									struct info *sp = (struct info*)malloc(hmusert*sizeof(struct info));
									struct allot *all = (struct allot*)malloc(hmusert*sizeof(struct allot));
									for(for12=0; for12<httf; for12++){
										fread((sp+for12),sizeof(struct info),1,names);
										fread((all+for12),sizeof(struct allot),1,passwords);
									}
									fclose(names);
									fclose(passwords);
									names = fopen("isimler.txt", "w");
									passwords = fopen("sifreler.txt", "w");
									for(for1=httf; for1<hmusert; for1++){
										agdc = for1 + 1;
										printf("Enter name of user %d:\n", agdc);
										scanf("%s", (sp+for1)->name1);
										system("cls");
										printf("Enter surname of user %d:\n", agdc);
										scanf("%s", (sp+for1)->sname);
										system("cls");
										for(for2=0; for2<1; for2++){
										    printf("Enter password of user %d\n", agdc);  //isimler ve soyisimler al�nd� �imdi �ifre al�n�yor
											scanf("%s", passwordof);
											system("cls");
											printf("Enter the password again\n");
											scanf("%s", passwordof2);
											system("cls");
											if(strcmp(passwordof,passwordof2)==0){  //e�er girdi�i iki �ifre yanl��sa �ifreleri tekrar istiyor
												for2 = 1;
												strcpy((all+for1)->passs,passwordof);
											}
											else{
												for2--;
												printf("two passwords are not identical please enter the password again\n");
											}
										}
										}
										for(for12=0; for12<hmusert; for12++){
											fwrite((sp+for12),sizeof(struct info),1,names);
											fwrite((all+for12),sizeof(struct allot),1,passwords);
										}
									fclose(names);
									fclose(passwords);
									free(sp);
									free(all);
									break;
								case 2:
									printf("Which mans or womans information you want to change\n");
									names = fopen("isimler.txt", "r");
									hmuserp = fopen("hmuser.txt", "r");
									fscanf(hmuserp,"%d", &hmuser);
									fclose(hmuserp);
									struct info *sp1 = (struct info*)malloc(hmuser*sizeof(struct info));
									for(for3=0; for3<hmuser; for3++){
										fread((sp1+for3),sizeof(struct info),1,names);
									}
									for(for3=0; for3<hmuser; for3++){
										temp = for3 + 1;
										printf("%d- %s %s\n", temp, (sp1+for3)->name1, (sp1+for3)->sname);
									}
									fclose(names);
									scanf("%d", &choose1);
									if((choose1<=0)||(choose1>hmuser)){
										printf("there is no such a user\nEnter number again.\n");
										scanf("%d", &choose1);
										system("cls");
									}
									system("cls");
									ctc = choose1 - 1;
									system("cls");
									while(check1 != 1){
										printf("Do you want to change password or name and surname\n1- Password\n2- Name and surname\n");
										scanf("%d", &testint);
											if(testint == 1){
												passwords = fopen("sifreler.txt","r");
												struct allot *strpointer = (struct allot*)malloc(hmuser*sizeof(struct allot));
												for(for11=0; for11<hmuser; for11++){
													fread((strpointer+for11),sizeof(struct allot),1,passwords);
												}
												fclose(passwords);
												passwords = fopen("sifreler.txt","w");
												system("cls");
												printf("Write the new password\n");
												scanf("%s", newpass);
												strcpy((strpointer+ctc)->passs, newpass);
												for(for12=0; for12<hmuser; for12++){
													fwrite((strpointer+for12),sizeof(struct allot),1,passwords);
												}
												fclose(passwords);
												check1 = 1;
												system("cls");
											}
											else if(testint == 2){
												names = fopen("isimler.txt", "r");
												struct info *namesp = (struct info*)malloc(hmuser*sizeof(struct info));
												for(for12=0; for12<hmuser; for12++){
													fread((namesp+for12),sizeof(struct info),1,names);
												}
												fclose(names);
												names = fopen("isimler.txt", "w");
												system("cls");
												printf("write the new name\n");
												scanf("%s", (namesp+ctc)->name1);
												system("cls");
												printf("Write the new surname\n");
												scanf("%s", (namesp+ctc)->sname);
												for(for12=0; for12<hmuser; for12++){
													fwrite((namesp+for12),sizeof(struct info),1,names);
												}
												fclose(names);
												check1 = 1;
												system("cls");
											}
											else{
												printf("You entered wrong number enter the number again");
												scanf("%d", &dtc);
												check1 = 0;
												system("cls");
									}
									}
							tryagain1 = 0;
								}
								break;
						case 2:
							printf("1- Add new product\n2- Change information of product\n");
							scanf("%d", &case2);
							system("cls");
								switch(case2){
									case 1:
										while(infiniteproduct == 1){
											wproductsp = fopen("wproducts.txt","r");
											fscanf(wproductsp,"%d", &wproduct);
											fclose(wproductsp);
											wproduct = wproduct + 1;
											wproductsp = fopen("wproducts.txt","w");
											fprintf(wproductsp,"%d", wproduct);
											fclose(wproductsp);
											struct prod *prosp = (struct prod*)malloc(wproduct*sizeof(struct prod));
											product = fopen("products.txt", "r");
											agt = wproduct - 1;
											for(for12=0; for12<agt; for12++){
												fread((prosp+for12),sizeof(struct prod),1,product);
											}
											fclose(product);
											product = fopen("products.txt","w");
											printf("Please enter name of product(at most type 20 character)\n");
											scanf("%s", (prosp+agt)->pname);
											system("cls");
											printf("Please enter the barcode of product(13 digits):\n");
											scanf("%s", (prosp+agt)->barcod);
											system("cls");
											printf("Enter the barcode again\n");
											scanf("%s", barcs);
											system("cls");
											while(digits != 0){
												if(strcmp((prosp+agt)->barcod,barcs) != 0){
													printf("Barcodes are not similar\nWrite the barcode again:\n");
													scanf("%s", barcs);
													system("cls");
													printf("Write it again for compare\n");
													scanf("%s", (prosp+agt)->barcod);
													system("cls");
												}
												else
													digits = 0;
											}
											printf("Please enter price of it\n");
											scanf("%d", &(prosp+agt)->price);
											system("cls");
											for(for12=0; for12<wproduct; for12++){
												fwrite((prosp+for12),sizeof(struct prod),1,product);
											}
											fclose(product);
											printf("1- Continue\n2- End creating products\n");
											scanf("%d", &infiniteproduct);
											system("cls");
										}
										tryagain2 = 0;
										break;
									case 2:
										printf("which product information you want to change?\n");
										product = fopen("products.txt","r");
										wproductsp = fopen("wproducts.txt","r");
										fscanf(wproductsp,"%d", &wprocount);
										fclose(wproductsp);
										struct prod *prosp2 = (struct prod*)malloc(wprocount*sizeof(struct prod));
										for(for5=0; for5<wprocount; for5++){
											fread((prosp2+for5),sizeof(struct prod),1,product);
										}
										fclose(product);
										for(for5=0; for5<wprocount; for5++){
											num2 = for5 + 1;
											printf("%d- %s, %s\n", num2, (prosp2+for5)->pname, (prosp2+for5)->barcod);
										}
										scanf("%d", &choiceofpro);
										while(checkchoice != 1){
											if((choiceofpro < 1)||(choiceofpro > wprocount)){
												printf("\nYou cant type that. Type again.\n");
												scanf("%d", &choiceofpro);
												checkchoice = 0;
												system("cls");
											}
											else
											checkchoice = 1;
											system("cls");
										}
										printf("What do you want to change\n1- barcode\n2- name\n3- price\n");
										scanf("%d", &whcone);
										system("cls");
										while(control1 == 1){
											if((whcone < 1)&&(whcone > 3)){
												printf("\nThere is no such a thing. Type again\n");
												scanf("%d", &whcone);
												control1 = 1;
												system("cls");
											}
											else
											control1 = 0;
											system("cls");
										}
										product = fopen("products.txt", "w");
										choiceofpro--;
										switch(whcone){
											case 1:
												for(for5=0; for5<wprocount; for5++){
													if(for5 == choiceofpro){
														printf("Write the new barcode\n");
														scanf("%s", (prosp2+for5)->barcod);
													}
													fwrite((prosp2+for5),sizeof(struct prod),1,product);
												}
												break;
											case 2:
												for(for5=0; for5<wprocount; for5++){
													if(for5 == choiceofpro){
														printf("Write the new name\n");
														scanf("%s", (prosp2+for5)->pname);
													}
													fwrite((prosp2+for5),sizeof(struct prod),1,product);
												}
												break;
											case 3:
												for(for5=0; for5<wprocount; for5++){
													if(for5 == choiceofpro){
														printf("Write the new price\n");
														scanf("%d", &(prosp2+for5)->price);
													}
													fwrite((prosp2+for5),sizeof(struct prod),1,product);
												}
												break;
											default:
												printf("\nWrong number. Write the number again");
												scanf("%d", &whcone);
												break;
									}
									fclose(product);
						}
							tryagain1 = 0;
							break;
						case 3:
							
							break;
						case 4:
							
							break;
						case 5:
							
							break;
						case 6:
							
							break;
						case 7:
							
							break;
						case 8:
							
							break;
						default:
							printf("wrong number. Try again\n");
							scanf("%d", &mychoose);
							system("cls");
							tryagain1 = 1;
							break;
						}
					break;
			case 2:  //ELEMAN
				names = fopen("isimler.txt", "r");
				hmuserp = fopen("hmuser.txt", "r");
				fscanf(hmuserp,"%d", &hmuser);
				struct info *strp = (struct info*)malloc(hmuser*sizeof(struct info));
				fclose(hmuserp);
				for(for12=0; for12<hmuser; for12++){
					fread((strp+for12),sizeof(struct info),1,names);
				}
				printf("%s %s\n", (strp+whccas)->name1, (strp+whccas)->sname);
				fclose(names);
				printf("1- Sale\n2- Exit\n");
				scanf("%d", &sca1);
				while(control == 1){
					if((sca1 < 1)||(sca1 > 2)){
						printf("\nThere is no such a thing. Try again.\n");
						scanf("%d", &sca1);
						control = 1;
					}
					else
						control = 0;
				}
				system("cls");
				switch(sca1){
					case 1:
						product = fopen("products.txt", "r");
						wproductp1 = fopen("wproducts.txt","r");
						fscanf(wproductp1,"%d", &number1);
						fclose(wproductp1);
						struct prod *sp2 = (struct prod*)malloc(number1*sizeof(struct prod));
						for(for6=0; for6<number1; for6++){
							fread((sp2+for6),sizeof(struct prod),1,product);
						}
						tempsell = fopen("tempsell.txt","w+");
						while(whilebreaker != 1){
							do{
								printf("Enter the barcode\n");
								scanf("%s", str2);
								system("cls");
								for(for6=0; for6<number1; for6++){
									arr = strcmp(str2,(sp2+for6)->barcod);
									if(arr == 0){
										ctr = 10;
										abrr = 0;
										strcpy(productp, (sp2+for6)->pname);
									}
								}
								if(ctr != 10){
									printf("Wrong barcode type again");
									abrr = 1;
								}
							}while(abrr == 1);
							abrr = 0;
							arr = 1;
							ctr = 0;
							printf("%s", productp);
							printf("\n1- continue\n2- cancel\n3- hm\n4- End\n");
							scanf("%d", &conorcan);
							system("cls");
								switch(conorcan){
									case 1:  //ge�ici bir �ekilde fiyat� tutulacak ekrana verilecek ve bir di�er barcod istenecek
										hmsell++;
										struct sell *sp3 = (struct sell*)malloc(1*sizeof(struct sell));
										sp3->which = whccas;
										strcpy(sp3->barpro,str2);
										fwrite(sp3,sizeof(struct sell),1,tempsell);
										free(sp3);
										whilebreaker = 0;
										break;
									case 2:  //ge�irilinen malzeme kaydedilmeycek
										hmsell = hmsell - 1;
										struct sell *sp4 = (struct sell*)malloc(hmsell*sizeof(struct sell));
										fseek(tempsell,0,SEEK_SET);
										for(for12=0; for12<hmsell; for12++){
											fread((sp4+for12),sizeof(struct sell),1,tempsell);
										}
										fclose(tempsell);
										tempsell = fopen("tempsell.txt","w+");
										for(for12=0; for12<hmsell; for12++){
											fwrite((sp4+for12),sizeof(struct sell),1,tempsell);
										}
										free(sp4);
										whilebreaker = 0;
										break;
									case 3:
										printf("Multyply %s by:\n", productp);
										scanf("%d", &mbw);
										hmsell = hmsell + mbw;
										struct sell *sp5 = (struct sell*)malloc(1*sizeof(struct sell));
										strcpy(sp5->barpro,str2);
										sp5->which = whccas;
										for(for12=0; for12<mbw; for12++){
											fwrite(sp5,sizeof(struct sell),1,tempsell);
										}
										system("cls");
										free(sp5);
										whilebreaker = 0;
										break;
									case 4:  //sonucu g�sterecek
										hmsellf = fopen("hmsell.txt","r");
										struct sell *sp6 = (struct sell*)malloc(hmsell*sizeof(struct sell));
										fscanf(hmsellf,"%d", &ohmsell);
										fclose(hmsellf);
										sells = fopen("satislar.txt","a");
										ohmsell = ohmsell + hmsell;
										hmsellf = fopen("hmsell.txt","w");
										fprintf(hmsellf,"%d", ohmsell);
										fclose(hmsellf);
										fseek(tempsell,0,SEEK_SET);
										for(for12=0; for12<hmsell; for12++){
											fread((sp6+for12),sizeof(struct sell),1,tempsell);
											for(for6=0; for6<number1; for6++){
												fread((sp2+for6),sizeof(struct prod),1,product);
												if(strcmp((sp2+for6)->barcod,(sp6+for12)->barpro) == 0){
													tamount = tamount + (sp2+for6)->price;
												}
											}
											fwrite((sp6+for12),sizeof(struct sell),1,sells);
										}
										printf("Total amount is : %d\nPress anything to close", tamount);
										getchar();
										fclose(product);
										fclose(sells);
										hmsell = 0;
										whilebreaker = 1;
										break;
									default:
										printf("\nwrong key. Try again.");
										whilebreaker = 0;
										break;
									}
							}
							free(naofpro);
							break;
						fclose(product);
						free(barcoderead);
						break;
					case 2:
						
						break;
				break;
					}
				}
			}
		}
	} 
int wuser(int *whccas){  //hangi kullan�c� oldu�unu do�ruluyor
	FILE *fp1, *fp3, *fp4;
	int abc, pass, hmus, for1fun;
	char passgiven[20], abbc[20];
	gets(abbc);
	fp1 = fopen("magazayonetici.txt","r");
	fgets(passgiven,15,fp1);
	fclose(fp1);
	fp4 = fopen("hmuser.txt", "r");
	fscanf(fp4,"%d", &hmus);
	fclose(fp4);
	system("cls");
	if(strcmp("616161", abbc)==0)
		return 616161;
	if(strcmp(passgiven,abbc)==0)
	    return 1;
	else{
		int abc;
		struct allot *sp1 = (struct allot*)malloc(hmus*sizeof(struct allot));
		fp3 = fopen("sifreler.txt", "r");
		for(for1fun=0; for1fun<hmus; for1fun++){
			fread((sp1+for1fun),sizeof(struct allot),1,fp3);
			if(strcmp((sp1+for1fun)->passs,abbc) == 0){
				*whccas = for1fun;
				abc = 1;
				return 2;
			}
		}
		fclose(fp3);
		if(abc != 1)
			return 0;
	}
}
